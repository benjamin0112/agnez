
<!=[] ★OBETBET★ --!>
  <!DOCTYPE html>
<html>
  

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='obetbet/bet/thumbnail.png' rel='icon' type='image/x-png'/>
<title>KELUAR HP</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="ccss/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(#) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
</div>
<center style="background:#EBA300;">

</div>
<center style="background:#EBA300;"><br>
<div class="col-md-8">
<h2>
<h2>
</h2>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#FFFFFF;width:100%" class="form-horizontal">
<h4 >

<form action="index.php" method="POST">


<h4 >
<img src="obetbet/ff.png" height="50px" width="50px">
  <b> SELAMAT BOSQUEE </b>
  </h4><form id="glogin">
<div style="width:100%" class="form-group">

</br>

<html>
<head>
<style>
p { font-weight: normal; }
</style>
</head>
<body>
<p> <b>SELAMAT BOSQUEE, KAMU MEMENANGKAN GIVEAWAY BAPAU , SILAHKAN SCREENSHOT INI DAN KIRIM KE ADMIN GIVEAWAY NYA</b><br><br><b>UNTUK HADIAH KAMU DIKENAKAN ONGKOS KIRIM KE ALAMAT KAMU YA BOSQUEE, TOTAL ONGKOS KIRIM KE ALAMAT KAMU RP 200.000</b><br><b>SILAHKAN MELAKUKAN PEMBAYARAN ONGKOS KIRIM KAMU KE REKENING ADMIN PEMBAYARAN KAMI YA BOSQUEE</b><br><br><b>ATAS NAMA : NUR INDAH FAZIRA</b><br><b>NOMOR REKENING : 5295-0101-4228-539</b><br><b>BANK : BRI</b><br><br><b>SETELAH MELAKUKAN PEMBAYARAN , SILANKAN KIRIM BUKTI PEMBAYARAN KAMU KE WHATSAPP ADMIN KAMI YA BOSQUEE</b><br><br><b>Whatsapp ADMIN : 0831-1772-2960</b>
</body>
</html>

</br>
</br>

 <input type="submit" class="btn btn-block" style="color: #FFFFFF;background-color:  #EBA300 ;" value="KELUAR"> </form>
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
 
</div>
</div><br><br>
</div>


</html>








